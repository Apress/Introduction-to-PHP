/*	game.js
	================================================
	Guessing Game
	================================================ */

	'use strict';

	window.onerror=function(message,url,line) {
		alert(`Error: ${message}\n${url}: ${line}`);
	};

	init();
	function init() {
		var button = document.querySelector('button#startgame');
		button.onclick=playGame;
	}

	function playGame() {
		//	Set up the data
			let min, max;
			let answer, guess;
			let message;

		//	Initialise
			[min,max] = [1,100];
			answer = random(100);
			message = 'Guess the Number';

		do {
			guess = prompt(`${message}\nFrom ${min} to ${max}`);
			if(guess === null) return 'game cancelled';
			guess = parseInt(guess) || 0;

			if(guess < answer) {		//	Too Small
				message = 'Too Low';
				min = guess + 1;
			}
			else if(guess > answer) {	//	Too Big
				message = 'Too High';
				max = guess -	1;
			}
			else {						//	Correct
				alert('Correct');
			}
		} while(guess != answer);

		return 'game over';

	}

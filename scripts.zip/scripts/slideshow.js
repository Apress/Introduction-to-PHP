/*	Slide Show
	================================================

	================================================ */

	'use strict';

	window.onerror=function(message, url, line) {
		alert(`Error: ${message}\n${url}: ${line}`);
	};

	init();

	function init() {
		let images = [
			'bamboo.jpg','bird.jpg','bromeliad.jpg','bush-panorama.jpg',
			'canal.jpg','church.jpg','cityscape.jpg','emu.jpg',
			'gum-nuts.jpg','hanging-rock.jpg','hut.jpg','koala.jpg',
			'kookaburra.jpg','lake.jpg','lantern.jpg','light-house.jpg',
			'lorikeet.jpg','mountain-panorama.jpg','rocks.jpg','rose.jpg',
			'steps.jpg','sunset.jpg','tall-trees.jpg','tea-leaf.jpg',
			'train.jpg','waterfall.jpg'
		];

		let images2 = [
			{ src: 'bamboo.jpg', caption: 'Bamboo Forest In Japan' },
			{ src: 'bird.jpg', caption: 'Bird in Flight' },
			{ src: 'bromeliad.jpg', caption: 'Bromeliad Flower' },
			{ src: 'bush-panorama.jpg', caption: 'Panorama of Australian Bush' },
			{ src: 'canal.jpg', caption: 'A Canal in Holland' },
			{ src: 'church.jpg', caption: 'Old Church in Brisbane at Night' },
			{ src: 'cityscape.jpg', caption: 'A City in Japan' },
			{ src: 'emu.jpg', caption: 'Australian Emu' },
			{ src: 'gum-nuts.jpg', caption: 'Some Gum Nuts' },
			{ src: 'hanging-rock.jpg', caption: 'Rock Out Crops in Victoria' },
			{ src: 'hut.jpg', caption: 'Old Bush Hut' },
			{ src: 'koala.jpg', caption: 'A Koala doing what Koalas normally do …' },
			{ src: 'kookaburra.jpg', caption: 'A Kookaburra Looking Back' },
			{ src: 'lake.jpg', caption: 'A Lake in Japan' },
			{ src: 'lantern.jpg', caption: 'Lantern at a Japanese Shrine' },
			{ src: 'light-house.jpg', caption: 'A Light House' },
			{ src: 'lorikeet.jpg', caption: 'Australian Lorikeet' },
			{ src: 'mountain-panorama.jpg', caption: 'Mountain Panorama in Japan' },
			{ src: 'rocks.jpg', caption: 'Rock Outcrop in Lake' },
			{ src: 'rose.jpg', caption: 'A Yellow Rose' },
			{ src: 'steps.jpg', caption: 'Stone Steps in a Garden' },
			{ src: 'sunset.jpg', caption: 'Sunset in the Clouds' },
			{ src: 'tall-trees.jpg', caption: 'Trees in Australian Bush' },
			{ src: 'tea-leaf.jpg', caption: 'A Leaf of the Camellia Sinensis Plant' },
			{ src: 'train.jpg', caption: 'Train approaching the Station' },
			{ src: 'waterfall.jpg', caption: 'Waterfall in the Wood' }
		];
		doSlides(images2, 'div#slides', 3000);
	}

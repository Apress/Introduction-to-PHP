/*	Ajax
	================================================ */

	'use strict';

	window.onerror=function(message,url,line) {
		alert(`Error: ${message}\n${url}: ${line}`);
	};

	init();
	function init() {
		ajaxContent();
		ajaxSlideshow();
		ajaxLightbox();
		ajaxCountries();
	}

	function ajaxContent() {
		let links = document.querySelector('ul#links');
		let content = document.querySelector('div#content');

		links.onclick = event => {
		    event.preventDefault();
		    fetch(event.target.href)
		    .then(response => response.text())
		    .then(text => {
		        content.innerHTML = text;
		    });
		}
	}

	function ajaxSlideshow() {
		fetch('images/slides/slides.json')
		.then(response => response.json())
		.then(data => {
		    doSlides(data,'div#slides',3000);
		});
	}

	function ajaxLightbox() {
		let catalogue = document.querySelector('div#catalogue');
		fetch('images/slides/slides.json')
		.then(response => response.json())
		.then(data => {
			data.forEach(item => {
				catalogue.insertAdjacentHTML(
					'beforeend',
					`<a href="images/photos/large/${item.src}">
						<img src="images/photos/small/${item.src}"
							title="${item.caption}" alt="${item.caption}"
							width="160" height="120"
						>
					</a>`
				);
			});
			doLightbox('div#catalogue');
		});
	}

	function ajaxCountries() {
		let countriesForm = document.querySelector('form#country-details');
		countriesForm.elements['id'].append(new Option('Select …',''));

		fetch('https://pure-javascript.net/resources/countries.php?list')
		.then(response => response.json())
		.then(data => {
		    data.forEach(item=> {
		        countriesForm.elements['id'].append(new Option(item.name,item.id));
		    });
		});

		countriesForm.onchange = event => {
			fetch(`https://pure-javascript.net/resources/countries.php?id=${event.target.value}`)
			.then(response => response.json())
			.then(data => {
				countriesForm.elements['local-name'].value = data['local_name'] ?? '&nbsp;';
				countriesForm.elements['tld'].value = data['tld'] ?? '&nbsp;';
				countriesForm.elements['continent'].value = data['continent'] ?? '&nbsp;';
				countriesForm.elements['currency'].value = data['currency'] ?? '&nbsp;';
			});
		}
	}

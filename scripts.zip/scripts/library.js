/*	JavaScript Library
	================================================
	================================================ */

	'use strict';

/*	random(max)
	================================================
	Returns a random integer between 1 and max
	================================================ */

	function random(max) {
		return Math.floor(Math.random()*max)+1;
	}

/*	doSlides(images, containerSelector, delay=3000)
	================================================
	Turns a container element into an slide show
	with a collection of images.
	================================================ */

	function doSlides(images, containerSelector, delay=3000) {
		//  Elements
			let container = document.querySelector(containerSelector);
			let img = container.querySelector('img');
			let prefetch = new Image();

		//	Cross Fade
			let crossFade = img.cloneNode();
			crossFade.id = 'crossfade';
			img.insertAdjacentElement('afterend', crossFade);


		//	Add Button
			let button=document.createElement('button');
			button.id='run-button';
			button.textContent='Start';
			button.addEventListener('click', toggle);
			container.insertAdjacentElement('beforeend' ,button);

		//  Add Caption
			let caption = document.createElement('p');
			container.insertAdjacentElement('beforeend', caption);


		//  Variables
			let slideNumber = 0;
			let running;    //  undefined

		img.addEventListener('click', toggle);
		//  next();     //  wait for user to start
		toggle();       //  start now

		document.onkeypress = function(event) {
			if(event.key==' ') {
				toggle();
				event.preventDefault();
			}
		};

	//	Fading
		let style = document.createElement('style');
		document.head.insertAdjacentElement('afterbegin',style);
/*
		style.sheet.insertRule(`
			div#slides>img {
				opacity: 0;
			}
		`);
		style.sheet.insertRule(`
			div#slides>img.showing {
				transition: opacity 1s;
				opacity: 1;
			}
		`);
*/

		style.sheet.insertRule(`
			 div#slides {
				 position: relative;
			 }
		 `);
		style.sheet.insertRule(`
			div#slides>img#crossfade {
				display: block;
				position: absolute;
				top: 0; left: 0;
				opacity: 1;
			}
		`);
		style.sheet.insertRule(`
			div#slides>img#crossfade.fading {
				transition: opacity 2500ms;
				opacity: 0;
			}
		`);

		function toggle() {
			if(!running) {
				running = setInterval(next,delay);
				next();
				button.textContent='Stop';
				container.classList.add('running');
			}
			else {
				running = clearInterval(running);
				button.textContent='Start';
				container.classList.remove('running');
			}
		 }

		function next() {
			//	Copy to Cross Fade
				crossFade.src = img.src;
				crossFade.alt = img.alt;

			//  Populate Image
				img.src = `images/slides/${images[slideNumber].src}`;

				img.classList.remove('showing');
				img.offsetHeight;
				img.classList.add('showing');

				crossFade.classList.remove('fading');
				crossFade.offsetHeight;
				crossFade.classList.add('fading');


				caption.textContent = images[slideNumber].caption;
				img.title = images[slideNumber].caption;
				img.alt = images[slideNumber].caption;
				slideNumber++;

			//  Wrap Around
				if(slideNumber >= images.length) slideNumber = 0;

			//  Prefetch
				prefetch.src = `images/slides/${images[slideNumber].src}`;
		}
	}



/*	toggleHeadingContent(container)
	================================================
	Toggles heading sections. Use the following strucure:

	div#containerid
		h2
		div
			content
		h2
		div
			content
		h2
		div
			content
	================================================ */

	function toggleHeadingContent(container) {
		let headings = document.querySelectorAll(`${container}>h2`);
		if(!headings.length) return;

		headings.forEach(heading => {
			heading.onclick = toggle;
		});

		let opened = null;

		function toggle() {
			//	event.target.classList.toggle('open');
			if(opened) opened.classList.remove('open');

			if(event.target == opened) { 		//	Forget
				opened = null;
			}
			else {
				event.target.classList.add('open');


				opened = event.target;
			}
		}
	}

/*	toggleNestedLists(menuId)
	================================================
	Toggles nested lists.

	The structure should be something like:

	<ul id="…">
		<li>item
			<ul>
				<li>item</li>
				<li>item</li>
			</ul>
		</li>
		<li>item
			<ul>
				<li>item</li>
				<li>item</li>
			</ul>
		</li>
	</ul>
	================================================ */

	function toggleNestedLists(menuId) {
		let ul = document.querySelector(`ul#${menuId}`);

		ul.onclick = toggle;

		if(!CSS.supports('selector(:has(ul))')) {
			ul.querySelectorAll('li').forEach(li => {
				if(li.querySelector('ul')) li.classList.add('nested');
			});
		}

		function toggle(event) {
			if(!event.target.querySelector('ul')) return;
			event.target.classList.toggle('open');
		}
	}

	function toggleNestedLists2(menuId) {
		let ul = document.querySelector(`ul#${menuId}`);
		ul.onclick = toggle;

		if(!CSS.supports('selector(:has(ul))')) {
			ul.querySelectorAll('li').forEach(li => {
				if(li.querySelector('ul')) li.classList.add('nested');
			});
		}

		function toggle(event) {
			if(!event.target.matches(':is(.nested,:has(ul))')) return;
			event.target.classList.toggle('open');
		}
	}

/*	deselectableRadio(buttons)
	================================================
	Allows a group of radio buttons to be deselected.
	================================================ */

	function deselectableRadio(buttons) {
		deselectableRadio.selected ??= null;
		buttons.forEach(b => {
			b.onclick = event => {
				if(event.target == deselectableRadio.selected) {
					event.target.checked = false;
					deselectableRadio.selected = null;
				}
				else deselectableRadio.selected = event.target;
			};
		});
	}

/*  function doLightbox(container)
	================================================
	Function to implement lightbox functionality for
	a gallery of images.

	Use the following Structure:

	<div id="…">
		<a href="…"><img src="…" title="…"></a>
		<a href="…"><img src="…" title="…"></a>
		<a href="…"><img src="…" title="…"></a>
	</div>

	The anchors include a reference to the larger image.
	The images include a thumbnail of the image.
	================================================ */

	function doLightbox(container) {
		var anchors = document.querySelectorAll(`${container}>a`);

		anchors.forEach(a => {
			a.onclick = show;
		});

		let currentAnchor;	//	current anchor

		//	Create Elements
			var background = document.createElement('div');

			var figure = document.createElement('figure');
			var img = document.createElement('img');
			var figcaption = document.createElement('figcaption');

			background.id = 'lightbox-background';
			figure.id = 'lightbox';

			figure.appendChild(img);
			figure.appendChild(figcaption);

			document.body.appendChild(background);
			document.body.appendChild(figure);

		//	Style Sheet
			let style = document.createElement('style');
			document.head.insertAdjacentElement('afterbegin',style);

		//	Lightbox Element Styles
			style.sheet.insertRule(`
				div#lightbox-background {
						position: fixed;
						top: 0; left: 0; width:100%; height: 100%;
						z-index: 1;
						background-color: rgb(0,0,0,0.5);
					}
			`);
			style.sheet.insertRule(`
				figure#lightbox {
						position: fixed;
						top: 50%; left: 50%; margin-right: -50%;
						transform: translate(-50%, -50%);
						z-index: 2;
					}
			`);

		//	Showing & Hiding
			background.onclick = hide;
			hide();	//	hide now

			function loadImage() {
				let currentImage = currentAnchor.querySelector('img');
				//	populate image element
					img.src = currentAnchor.href;
				//	caption text
					figcaption.textContent = img.alt = img.title = currentImage.title;

				img.onload = event => {
					background.style.display = 'block';
					figure.classList.add('open');
					figure.classList.remove('closed');
				};
			}

			function show(event) {
				event.preventDefault();
				currentAnchor = event.currentTarget;
				loadImage();

				document.addEventListener('keydown',doKeys);
			}
			function hide(event) {
				background.style.display = 'none';
				figure.classList.remove('open');
				figure.classList.add('closed');

				document.removeEventListener('keydown',doKeys);
			}

			function doKeys(event) {
				event.preventDefault();

				switch(event.key) {
					case 'Esc':	//	Old Version
					case 'Escape':
						hide();
						break;
					case 'Left':	//	Old Version
					case 'ArrowLeft':
						currentAnchor = currentAnchor.previousElementSibling ||
							currentAnchor.parentNode.lastElementChild;
						loadImage();
						break;
					case 'Right':	//	Old Version
					case 'ArrowRight':
						currentAnchor = currentAnchor.nextElementSibling ||
							currentAnchor.parentNode.firstElementChild;
						loadImage();
						break;
					case 'Home':
					case 'Up':		//	Old Version
					case 'ArrowUp':
						currentAnchor = currentAnchor.parentNode.firstElementChild;
						loadImage();
						break;
					case 'End':
					case 'Down':	//	Old Version
					case 'ArrowDown':
						currentAnchor = currentAnchor.parentNode.lastElementChild;
						loadImage();
						break;
				}
			}
	}

/*	Mortgage Calculator
	================================================ */

	'use strict';
	window.onerror=function(message,url,line) {
		alert(`Error: ${message}\n${url}: ${line}`);
	};

	doCalculator();

	function doCalculator() {
		let calculatorForm = document.querySelector('form#data');
		calculatorForm.elements['calculate'].onclick = doit;
		let format = Intl.NumberFormat(
			'en-AU',
			{ style: 'currency', currency: 'aud' }
		).format;

		//	Restore Values
			if(localStorage.getItem('data')) {
				['principal','term','frequency','rate'].forEach(item => {
					calculatorForm.elements[item].value = localStorage.getItem(item);
				});
			}


		function doit(event) {
			event.preventDefault();

			let data = {};

			['principal','term','frequency','rate'].forEach(item => {
				data[item] = calculatorForm.elements[item].value.trim();
				data[item] = parseFloat(data[item]) || 0;
				calculatorForm.elements[item].value = data[item];
			});

			let p = data.principal;
			let n = data.term * data.frequency;
			let r = data.rate / data.frequency / 100;


			let repayment = p * r * (1+r)**n / ((1+r)**n - 1);
			calculatorForm.elements['result'].value = format(repayment);

			//	Store Values
				localStorage.setItem('data', true);
				['principal','term','frequency','rate'].forEach(item => {
					localStorage.setItem(item, data[item]);
				});
		}
	}

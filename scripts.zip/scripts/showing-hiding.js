/**	Menu
	================================================
	================================================ */

	'use strict';
	window.onerror=function(message, url, line) {
		alert(`Error: ${message}\n${url}: ${line}`);
	};

	init();

	function init() {
		toggleHeadingContent('div#headings');
		toggleNestedLists('menu');
		doForm();
	}

	function doForm() {
		let form = document.querySelector('form#music');
		let buttons = form.elements['musical-style'];
		deselectableRadio(buttons);

		form.elements['ok'].onclick = event => {
			event.preventDefault();
		};

	}

<header>
	<div id="banner"><span>Australia</span><span>Down Under</span></div>
	<h1><?= isset($pageheading) ? $pageheading : 'Australia Down Under'; ?></h1>
</header>

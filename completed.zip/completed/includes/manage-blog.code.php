<?php
#   manage-blog.code.php

	const LIVE = true;

	if(!session_id()) {
		session_start();
		session_regenerate_id(true);
	}

	$root = str_replace($_SERVER['SCRIPT_NAME'], '',
		$_SERVER['SCRIPT_FILENAME']);

	$host = $_SERVER['HTTP_HOST'];
	$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on'
		? 'https'
		: 'http';

	if(!isset($_SESSION['user']) || !$_SESSION['admin']) {
		header("Location: $protocol://$host/admin.php");
		exit;
	}

	require_once "$root/includes/db.php";
	require_once "$root/includes/default-library.php";
	require_once "$root/includes/library.php";

	$CONFIG = parse_ini_file("$root/config.ini.php",true);

	//  Initialise
		$title = $precis = $article = '';
		$id = 0;
		$errors = '';
		$disabled = '';
		$markdown = '';

		$chooseImage = '';              //  Modified
		$previewImage = '<img src="%s" width="%s" height="%s" alt="%s"
			id="preview-new-image">';   //  New

		$pagetitle = 'Edit Blog';
		$pageheading = 'Edit Blog';

	//  Functions
		function getImageSelect($imageid=0) {
			global $pdo;

			$option = '<option value="%s" data-preview="%s" %s>%03s %s</option>';
			$select = [];

			$select[] = '<span>';
			$select[] = '<select name="use-image">';
			$select[] = sprintf($option, 0, '/images/blank.png', '', '   ', '[No Image]');

			foreach($pdo -> query('SELECT id, title, src FROM images')
			  as [$id, $title, $src]) {
				  $select[] =sprintf($option, $id, "/images/thumbnails/$src",
				  $id == $imageid ? ' selected' : '', $id, $title);
			}

			$select[] = '</select>';
			$select[] = '</span>';

			$select = implode($select);

			return $select;
		}

		function getImageButtons($imageid=0) {
			global $pdo, $CONFIG;

			$button = '<label>
				 <input type="radio" name="use-image" value="%s" %s>
				 <img src="%s" alt="%s" title="%s" width="%s" height="%s"
					 data-preview="%s">
				 </label>';
			 [$width, $height] = splitSize($CONFIG['images']['icon-size']);

			$buttons = [];

			$buttons[] = sprintf(
				$button, 0, 'checked', '/images/blank.png', 'none',
				'', $width, $height, '/images/blank.png'
			);

			foreach($pdo -> query('SELECT id, title, src FROM images')
			  as [$id, $title, $src]) {
				$buttons[] = sprintf(
					$button, $id, $id == $imageid ? ' checked' : '', "/images/icons/$src", $title,
					$title, $width, $height, "/images/thumbnails/$src"
				);
			}

			$buttons = implode($buttons);

			return $buttons;
		}

		function getArticle(int $id) {
			global $pdo, $CONFIG, $previewImage;

			$sql = "SELECT title, precis, created, updated, article, imageid, markdown
				FROM blog WHERE id=$id";
			$row = $pdo -> query($sql) -> fetch();

			if(!$row) return null;      //  exit if no data

			[$title, $precis, $created, $updated, $article, $imageid, $markdown] = $row;
			$article = pilcrow2nl($article);
			$created = date('d M Y g:i a', strtotime($created));
			$updated = date('d M Y g:i a', strtotime($updated));

			[$width, $height]
				= splitSize($CONFIG['images']['thumbnail-size']);

			if($imageid) {
				$sql = "SELECT title, src FROM images WHERE id=$imageid";
				$row = $pdo -> query($sql) -> fetch();
				if($row) {
					[$imagetitle, $src] = $row;
					$previewImage = sprintf(
						$previewImage,
						"images/thumbnails/$src", $width, $height, $imagetitle
					);
				}
			}
			else $previewImage = sprintf(
				$previewImage,
				'/images/blank.png', $width, $height, 'No Image'
			);

			return [$title, $precis, $created, $updated, $article,
				$imageid, $previewImage, $markdown];
		}

	//  Prepare Page
		if(isset($_POST['prepare-insert'])) {
			$pagetitle = 'Upload Article';
			$pageheading = 'Upload Article';

			[$width, $height]
				= splitSize($CONFIG['images']['thumbnail-size']);
			$previewImage = sprintf(
				$previewImage,
				'', $width, $height, 'No Image'
			);

			switch($CONFIG['blogedit']['use-image']) {
				case 'buttons':
					$chooseImage = getImageButtons();
					break;
				case 'select':
				default:
					$chooseImage = getImageSelect();
					break;
			}
		}

		if(isset($_POST['prepare-update'])) {
			$pagetitle = 'Edit Article';
			$pageheading = 'Edit Article';

			$id = intval($_POST['prepare-update'] ?? 0);
			[$title, $precis, $created, $updated, $article, $imageid,
				$previewImage, $markdown] = getArticle($id);

			$markdown = $markdown ? ' checked' : '';

			$chooseImage = $CONFIG['blogedit']['use-image']=='buttons'
				? getImageButtons($imageid)
				: getImageSelect($imageid);
		}

		if(isset($_POST['prepare-delete'])) {
			$pagetitle = 'Delete Article';
			$pageheading = 'Delete Article';

			$id = intval($_POST['prepare-delete'] ?? 0);
			[$title, $precis, $created, $updated, $article, $imageid,
				$previewImage, $markdown] = getArticle($id);

			$markdown = $markdown ? ' checked' : '';

			$disabled = ' disabled';
		}

	//  Get Submitted Data
		function getBlogData() {
			$id = intval($_POST['id']);
			$title = trim($_POST['title']);
			$precis = trim($_POST['precis']);
			$article = trim($_POST['article']);
			$image = null;
			$markdown = intval(isset($_POST['markdown']));

			$errors = [];

			//  Optional Image
				if(isset($_FILES['image']) && $_FILES['image']['error']
					!= UPLOAD_ERR_NO_FILE) {
					$imagetypes = ['image/gif', 'image/jpeg', 'image/png',
						'image/webp'];
					switch($_FILES['image']['error']) {
						case UPLOAD_ERR_OK:
						  if(!in_array($_FILES['image']['type'], $imagetypes))
								$errors[] = 'Not a suitable image file';
						  if(!is_uploaded_file($_FILES['image']['tmp_name']))
								$errors[] = 'Not an uploaded file';
						  break;
						case UPLOAD_ERR_INI_SIZE:
						case UPLOAD_ERR_FORM_SIZE:
						  $errors = 'File too big';
						  break;
						default:
						  $errors = 'Problem with file upload';
					}

					if(!$errors) {
						$image = [
							'imageName' => $_FILES['image']['name'],
							'imageFile' => $_FILES['image']['tmp_name']
						];
					}
				}
				else $image = $_POST['use-image'];

			//  Check Text
				if(!$title) $errors[] = 'Missing Title';
				if(!$precis) $errors[] = 'Missing Précis';
				if(!$article) $errors[] = 'Missing Article';

			return [$id, $title, $precis, $article, $image, $markdown, $errors];
		}

	 //  Add Blog Data
		function addBlogData(string $title, string $precis,
		  string $article, array|string $image=null, string $created=null,
		  string $updated=null, int $markdown=0) {
			global $pdo, $root, $CONFIG;

			$precis = nl2pilcrow($precis);
			$article = nl2pilcrow($article);

			$sql = 'INSERT INTO blog(title, precis, article, created, updated, markdown)
				VALUES(?, ?, ?, ?, ?, ?)';
			$pdoStatement = $pdo -> prepare($sql);
			$data = [$title, $precis, $article,
				$created?:date('Y-m-d H:i:s'), $updated?:date('Y-m-d H:i:s'),
				$markdown];
if(LIVE)	$pdoStatement->execute($data);

			$id = $pdo -> lastInsertId();

			if($image) addBlogImage($id, $image, $title, $precis);

			return $id;
		}

	//  Add Blog Image
		function addBlogImage(int $id, array|string $image,
		  string $title, string $precis) {
			global $pdo, $root, $CONFIG;

			if(is_array($image)) {
				['imageName'=>$name, 'imageFile'=>$file] = $image;

				$name = strtolower($name);
				$name = str_replace(' ', '-', $name);

				//  $description = nl2pilcrow($description);      //  **  Deleted

				$sql = 'INSERT INTO images(title, description, name, src, gallery)
					VALUES(?, ?, ?, ?, false)';                   //  **  Changed
				$pdoStatement = $pdo -> prepare($sql);
				$data = [$title, $precis, $name, $name];          //  **  Changed
if(LIVE)		$pdoStatement->execute($data);

				$imageid = $pdo -> lastInsertId();
				$src = sprintf('%06s-%s', $imageid, $name);       //  **  Changed

				$sql = 'UPDATE images SET src=? WHERE id=?';
				$pdoStatement = $pdo->prepare($sql);
if(LIVE)		$pdoStatement->execute([$src, $imageid]);         //  **  Changed

				$sql = 'UPDATE blog SET imageid=? WHERE id=?';
				$pdoStatement = $pdo->prepare($sql);
if(LIVE)		$pdoStatement->execute([$imageid, $id]);

				copy($file,
					"$root/{$CONFIG['images']['directory']}/originals/$src");

				resizeImage(
					"$root/{$CONFIG['images']['directory']}/originals/$src",
					"$root/{$CONFIG['images']['directory']}/display/$src",
					$CONFIG['images']['display-size']
				);
				resizeImage(
					"$root/{$CONFIG['images']['directory']}/originals/$src",
					"$root/{$CONFIG['images']['directory']}/thumbnails/$src",
					$CONFIG['images']['thumbnail-size']
				);
				resizeImage(
					"$root/{$CONFIG['images']['directory']}/originals/$src",
					"$root/{$CONFIG['images']['directory']}/icons/$src",
					$CONFIG['images']['icon-size']
				);
				resizeImage(
					"$root/{$CONFIG['images']['directory']}/originals/$src",
					"$root/{$CONFIG['images']['directory']}/scaled/$src",
					$CONFIG['images']['scaled'], ['method'=>'scale']
				);
			}
			elseif(is_numeric($image)) {
				$sql = 'UPDATE blog
					SET imageid=(select id from images where id=?)
					WHERE id=?';
				$pdoStatement = $pdo->prepare($sql);
if(LIVE)		$pdoStatement->execute([$image, $id]);
			}

			return $id;
		}

	//  Process
		if(isset($_POST['insert'])) {
			[$id, $title, $precis, $article, $image, $markdown, $errors] = getBlogData();

			if(!$errors) {  //  proceed
				$id = addBlogData($title, $precis, $article, $image, null, null, $markdown);

				//  Move On
					header("Location: $protocol://$host/admin-bloglist.php");
					exit;
			}
			else {          //  handle error
				$errors = sprintf('<p class="errors">%s</p>',
					implode('<br>',$errors));
			}
		}

		if(isset($_POST['update'])) {
			[$id, $title, $precis, $article, $image, $markdown, $errors] = getBlogData();
			$precis = nl2pilcrow($precis);
			$article = nl2pilcrow($article);

			if(!$errors) {  //  proceed
				$sql = 'UPDATE blog SET title=?, precis=?, article=?,
					 updated=?, markdown=? WHERE id=?';
				 $pdoStatement = $pdo -> prepare($sql);
				 $data = [$title, $precis, $article, date('Y-m-d H:i:s'), $markdown, $id];
if(LIVE)		 $pdoStatement->execute($data);

				 addBlogImage($id, $image, $title, $precis);

				//  Move On
					header("Location: $protocol://$host/admin-bloglist.php");
					exit;
			}
			else {          //  handle error
				$errors = sprintf('<p class="errors">%s</p>',
					implode('<br>',$errors));
			}
		}

		if(isset($_POST['delete'])) {
			$id = intval($_POST['id'] ?? 0);

			$pdo -> exec("DELETE FROM blog WHERE id=$id");

			//  Move On
				header("Location: $protocol://$host/admin-bloglist.php");
				exit;

		}

		if(isset($_POST['import'])) {
			$pdo -> exec('TRUNCATE TABLE blog');
			$pdo -> exec('DELETE FROM images WHERE NOT gallery');

			if(!isset($_FILES['import-file'])) $errors = 'Missing File';
			else {
				$mime = MimeType($_FILES['import-file']['tmp_name']);
				switch($_FILES['import-file']['error']) {
					case UPLOAD_ERR_OK:
						if($mime != 'application/zip' && $mime != 'text/csv')
							$errors = 'Not a suitable ZIP or CSV file';
						break;
					case UPLOAD_ERR_INI_SIZE:
					case UPLOAD_ERR_FORM_SIZE:
						$errors = 'File too big';
						break;
					case UPLOAD_ERR_NO_FILE:
						$errors = 'Missing File';
						break;
					default:
						$errors = 'Problem with file upload';
				}
			}

			if(!$errors) {
				if($mime == 'application/zip') {    //  extract Zip
					['files'=>$files, 'names'=>$names]
						= unzip($_FILES['import-file']['tmp_name'],
							"$root/uploads");
					if(
						!file_exists("$root/uploads/@blog.csv")
						|| MimeType("$root/uploads/@blog.csv") != 'text/csv'
					) $errors = 'No valid @blog.csv file';
				}
				else copy($_FILES['import-file']['tmp_name'],
					"$root/uploads/@blog.csv");                 //  copy CSV
			}

			if(!$errors) {
				$file = "$root/uploads/@blog.csv";
				$data = file($file, FILE_IGNORE_NEW_LINES |
					FILE_SKIP_EMPTY_LINES);
				$header = array_shift($data);
				$data = array_map('str_getcsv', $data);

				$imagetypes = ['image/gif', 'image/jpeg', 'image/png',
					'image/webp'];

				$keys = explode(' ','title precis article created updated image markdown');

				foreach($data as $row) {
					$row = array_pad($row, 7, null);
					$row = array_combine($keys, $row);
					$image = null;

					//  Check for an image
						if($row['image']
						  && file_exists("$root/uploads/{$row['image']}")
						  && in_array(MimeType("$root/uploads/{$row['image']}"),
							$imagetypes)
						) $row['image'] = [
							'imageName' => $row['image'],
							'imageFile' => "$root/uploads/{$row['image']}"
						];
						else $row['image'] = null;

					//  addBlogData()
#						addBlogData(...$row);                               //  PHP >= 8
						//  addBlogData(...array_values($row));             //  PHP >= 7.2
						//  addBlogData($row['title'], $row['precis'], $row[article],
						//    $row[created], $row[updated], $row[image], $row[markdown]);   //  Any  PHP

				}

				array_map('unlink', glob("$root/uploads/*"));

				//  Move On
					header("Location: $protocol://$host/admin-bloglist.php");
					exit;
			}
			else {
				$errors = sprintf('<p class="errors">%s</p>', $errors);
			}
		}

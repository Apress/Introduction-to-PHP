<?php
	$root = str_replace($_SERVER['SCRIPT_NAME'], '',
		$_SERVER['SCRIPT_FILENAME']);

	$pdo = require_once "$root/includes/db.php";
	require_once "$root/includes/default-library.php";
	require_once "$root/includes/library.php";

    $CONFIG = parse_ini_file("$root/config.ini.php",true);

	$sql = 'SELECT title, src, description FROM images
	        WHERE gallery=true ORDER BY rand()';
	[$title, $src, $description] = $pdo -> query($sql) -> fetch();


	$description = pilcrow2p($description);
    $image = '<img src="/images/thumbnails/%s" alt="%s" title="%s"
        width="%s" height="%s">';
    [$width, $height]
        = splitSize($CONFIG['images']['thumbnail-size']);
    $image = sprintf($image, $src, $title, $title, $width, $height);

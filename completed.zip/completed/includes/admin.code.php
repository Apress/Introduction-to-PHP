<?php
	if(!session_id()) {
		session_start();
		session_regenerate_id(true);
	}

	$root = str_replace($_SERVER['SCRIPT_NAME'], '',
		$_SERVER['SCRIPT_FILENAME']);
	$pdo = require_once "$root/includes/db.php";

	$errors = '';

	$message = '';

	if(isset($_POST['login'])) {
		$email=$_POST['email'];
		$password=$_POST['password'];

		$sql = 'SELECT id, givenname, familyname, hash, admin
			FROM users WHERE email=?';
		$pds = $pdo->prepare($sql);
		$pds -> execute([$email]);
		$row = $pds->fetch();

		if($row && password_verify($password, $row['hash'])) {
			$_SESSION['user'] = $row['id'];
			$_SESSION['givenname'] = $row['givenname'];
			$_SESSION['familyname'] = $row['familyname'];
			$_SESSION['email'] = $email;
			$_SESSION['admin'] = $row['admin'];
		}
		else {
			$errors='<p class="errors">Unsuccessful Login</p>';
		}
	}
	if(isset($_POST['logout'])) {
		session_unset();
		session_destroy();
		setcookie(session_name(), '', 0);
	}

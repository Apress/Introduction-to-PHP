<?php
/*	Pilcrow Functions
	================================================
	================================================ */

	function nl2pilcrow($text) {
		return str_replace(["\r\n","\r","\n"], '¶', $text);
	}

	function pilcrow2nl($text) {
		return str_replace('¶', PHP_EOL, $text);
	}

#	function pilcrow2p($text) {
#		return sprintf('<p>%s</p>', str_replace('¶', '</p><p>', $text));
#	}

	function pilcrow2p($text, $double=false) {
		if($double) return sprintf('<p>%s</p>',str_replace(['¶¶','¶'],['</p><p>','<br>'],$text));
		else return sprintf('<p>%s</p>',str_replace('¶','</p><p>',$text));
	}

/*	Paging
	================================================
	================================================ */

	function paging(int $page, int $pages) {
		$paging = [];

		$paging[] = $page == 1
			? '<span>«</span>'
			: '<a href="?page=1" data-page="1">«</a>';
		$paging[] = $page == 1
			? '<span>‹</span>'
			: sprintf('<a href="?page=%s" data-page="%s">‹</a>', $page - 1, $page - 1);

		$paging[] = $page == $pages
			? '<span>›</span>'
			: sprintf('<a href="?page=%s" data-page="%s">›</a>', $page + 1, $page + 1);
		$paging[] = $page == $pages
			? '<span>»</span>'
			: sprintf('<a href="?page=%s" data-page="%s">»</a>', $pages, $pages);

		return implode($paging);
	}

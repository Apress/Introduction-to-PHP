<?php
#   manage-images.code.php

	const LIVE = false;

	if(!session_id()) {
		session_start();
		session_regenerate_id(true);
	}

	$root = str_replace($_SERVER['SCRIPT_NAME'], '', $_SERVER['SCRIPT_FILENAME']);

	$host = $_SERVER['HTTP_HOST'];
	$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on'
		? 'https'
		: 'http';

	if(!isset($_SESSION['user']) || !$_SESSION['admin']) {
		header("Location: $protocol://$host/admin.php");
		exit;
	}

	require_once "$root/includes/db.php";
	require_once "$root/includes/default-library.php";
	require_once "$root/includes/library.php";

	$CONFIG = parse_ini_file("$root/config.ini.php",true);

	//	Functions
		function addImageData(string $name, string $title, string $description, $gallery=1) {
			global $pdo;

			$name = strtolower($name);
			$name = str_replace(' ', '-', $name);

		//	Add to the Database
			$description = nl2pilcrow($description);

			$sql = 'INSERT INTO images(title, description, name, src, gallery) VALUES(?, ?, ?, ?, ?)';
			$pdoStatement = $pdo -> prepare($sql);
			$data = [$title, $description, $name, $name, $gallery];
if(LIVE)	$pdoStatement->execute($data);

			$id = $pdo -> lastInsertId();
			$src = sprintf('%06s-%s', $id, $name);

			$sql = 'UPDATE images SET src=? WHERE id=?';
			$pdoStatement = $pdo->prepare($sql);
			$data = [$src, $id];
if(LIVE)	$pdoStatement->execute($data);

			return [$id, $src];
		}

		function addImageFile(string $file, string $src) {
			global $root, $CONFIG;
			copy($file, "{$root}/{$CONFIG['images']['directory']}/originals/{$src}");

			resizeImage(
				"{$root}/{$CONFIG['images']['directory']}/originals/{$src}",
				"{$root}/{$CONFIG['images']['directory']}/display/{$src}",
				$CONFIG['images']['display-size']
			);
			resizeImage(
				"{$root}/{$CONFIG['images']['directory']}/originals/{$src}",
				"{$root}/{$CONFIG['images']['directory']}/thumbnails/{$src}",
				$CONFIG['images']['thumbnail-size']
			);
			resizeImage(
				"{$root}/{$CONFIG['images']['directory']}/originals/{$src}",
				"{$root}/{$CONFIG['images']['directory']}/icons/{$src}",
				$CONFIG['images']['icon-size']
			);
			resizeImage(
				"{$root}/{$CONFIG['images']['directory']}/originals/{$src}",
				"{$root}/{$CONFIG['images']['directory']}/scaled/{$src}",
				$CONFIG['images']['scaled'], ['method'=>'scale']
			);
		}

	//	Initialise
		$id = 0;
		$title = $description = '';
		$errors = '';
		$disabled = '';
		$gallery = ' checked';

	//	Prepare Page
		if(isset($_POST['prepare-insert'])) {
			$pagetitle = 'Upload Image';
			$pageheading = 'Upload Image';

		}
		if(isset($_POST['prepare-update'])) {
			$pagetitle = 'Edit Image';
			$pageheading = 'Edit Image';

			$id = intval($_POST['prepare-update'] ?? 0);

			$sql = "SELECT title, src, description, gallery FROM images WHERE id=$id";
			[$title, $src, $description, $gallery] = $pdo -> query($sql) -> fetch();
			$description = pilcrow2nl($description);
			$gallery = $gallery ? ' checked' : '';
		}
		if(isset($_POST['prepare-delete'])) {
			$pagetitle = 'Delete Image';
			$pageheading = 'Delete Image';

			$id = intval($_POST['prepare-delete'] ?? 0);

			$sql = "SELECT title, src, description, gallery FROM images WHERE id=$id";
			[$title, $src, $description, $gallery] = $pdo -> query($sql) -> fetch();
			$description = pilcrow2nl($description);
			$gallery = $gallery ? ' checked' : '';

			$disabled = ' disabled';
		}


	//	Upload Blog Article

		if(isset($_POST['insert'])) {
			$title = trim($_POST['title']);
			$description = trim($_POST['description']);
			$gallery = intval(isset($_POST['gallery']));

			$errors = [];

			//	Check Text
				if(!$title) $errors[] = 'Missing Title';
				if(!$description) $errors[] = 'Missing Description';

			//	Check File
				$imagetypes = ['image/gif', 'image/jpeg', 'image/png', 'image/webp'];

				if(!isset($_FILES['image'])) $errors[] = 'Missing File';
				else switch($_FILES['image']['error']) {
					case UPLOAD_ERR_OK:
						//	if($_FILES['image']['size'] > 0x100000) $errors[] = 'File too big';
						if(!in_array($_FILES['image']['type'], $imagetypes))
							$errors[] = 'Not a suitable image file';
						if(!is_uploaded_file($_FILES['image']['tmp_name']))
							$errors[] = 'Not an uploaded file';
						break;
					case UPLOAD_ERR_INI_SIZE:
					case UPLOAD_ERR_FORM_SIZE:
						$errors[] = 'File too big';
						break;
					case UPLOAD_ERR_NO_FILE:
						$errors[] = 'Missing File';
						break;
					default:
						$errors[] = 'Problem with file upload';
				}

			//	Process
				if(!$errors) {	//	proceed
					$name = $_FILES['image']['name'];
					[$id, $src] = addImageData($name, $title, $description, $gallery);
					addImageFile($_FILES['image']['tmp_name'], $src);

					//	Finish Up
						$errors = '';
 						$title = $description = '';
						$id = 0;

				}
				else {			//	handle error
					$errors = sprintf('<p class="errors">%s</p>',implode('<br>',$errors));
				}

		}

	//	Import Blog Articles
		if(isset($_POST['import'])) {
			$pdo -> exec('TRUNCATE TABLE images');
			$directories = ['uploads', 'images/originals', 'images/display', 'images/thumbnails', 'images/icons', 'images/scaled'];
			foreach($directories as $dir) array_map('unlink', glob("$root/$dir/*"));

			if(!isset($_FILES['import-file'])) $errors = 'Missing File';
			else {
				$mime = MimeType($_FILES['import-file']['tmp_name']);
				switch($_FILES['import-file']['error']) {
					case UPLOAD_ERR_OK:
						if($_FILES['import-file']['type'] != 'application/zip')
							$errors = 'Not a suitable ZIP file';
						break;
					case UPLOAD_ERR_INI_SIZE:
					case UPLOAD_ERR_FORM_SIZE:
						$errors = 'File too big';
						break;
					case UPLOAD_ERR_NO_FILE:
						$errors = 'Missing File';
						break;
					default:
						$errors = 'Problem with file upload';
				}
			}

			if(!$errors) {
				['files'=>$files, 'names'=>$names] = unzip($_FILES['import-file']['tmp_name'], "$root/uploads");
				if(
					!file_exists("$root/uploads/@index.csv")
					|| MimeType("$root/uploads/@index.csv") != 'text/csv'
				) $errors = 'No valid @index.csv file';
			}

			if(!$errors) {
				$file = "$root/uploads/@index.csv";
				$data = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
				$header = array_shift($data);
				$data = array_map('str_getcsv', $data);

				$imagetypes = ['image/gif', 'image/jpeg', 'image/png', 'image/webp'];

				foreach($data as $item) {
					if(
						!file_exists("$root/uploads/$item[0]")
						|| !in_array(MimeType("$root/uploads/$item[0]"),$imagetypes)
					) continue;
					[, $src] = addImageData($item[0], $item[1], $item[2]);
					addImageFile("$root/uploads/$item[0]", $src);
				}

				array_map('unlink', glob("$root/uploads/*"));

				//	Move On
					header("Location: $protocol://$host/imagelist.php");
					exit;
			}
			else {
				$errors = sprintf('<p class="errors">%s</p>', $errors);
			}
		}

		if(isset($_POST['update'])) {
			$id = intval($_POST['id'] ?? 0);
#print_r($_POST);
			$title = trim($_POST['title']);
			$description=trim($_POST['description']);
			$gallery = intval(isset($_POST['gallery']));

			$errors = [];

			//	Check Text
				if(!$title) $errors[] = 'Missing Title';
				if(!$description) $errors[] = 'Missing Description';

			//	Replace Image?
				if(isset($_FILES['image']) && $_FILES['image']['error'] != UPLOAD_ERR_NO_FILE) {
					$imagetypes = ['image/gif', 'image/jpeg', 'image/png', 'image/webp'];
					switch($_FILES['image']['error']) {
						case UPLOAD_ERR_OK:
							if(!in_array($_FILES['image']['type'], $imagetypes))
								$errors[] = 'Not a suitable image file';
							if(!is_uploaded_file($_FILES['image']['tmp_name']))
								$errors[] = 'Not an uploaded file';
							break;
						case UPLOAD_ERR_INI_SIZE:
						case UPLOAD_ERR_FORM_SIZE:
							$errors = 'File too big';
							break;
						default:
							$errors = 'Problem with file upload';
					}

					if(!$errors) {
						$src = $pdo -> query("SELECT src FROM images WHERE id=$id")
							-> fetchColumn();
						addImageFile($_FILES['image']['tmp_name'], $src);
					}
				}

			//	Process
				if(!$errors) {	//	proceed
					$sql = 'UPDATE images SET title=?, description=?, gallery=? WHERE id=?';
					$prepared = $pdo -> prepare($sql);
if(LIVE)			$prepared -> execute([$title, nl2pilcrow($description), $gallery, $id]);
				}
				else {			//	handle error
					$errors = sprintf('<p class="errors">%s</p>',
						implode('<br>',$errors));
				}

			//	Move On
				header("Location: $protocol://$host/imagelist.php");
				exit;
		}

		if(isset($_POST['delete'])) {
			$id = intval($_POST['id'] ?? 0);

			$src = $pdo -> query("SELECT src FROM images WHERE id=$id")
				-> fetchColumn();

			$directories = ['images/originals', 'images/display', 'images/thumbnails',
				'images/icons', 'images/scaled'];
			foreach($directories as $dir) unlink("$root/$dir/$src");

			$pdo -> exec("DELETE FROM images WHERE id=$id");

			//	Move On
				header("Location: $protocol://$host/imagelist.php");
				exit;
		}

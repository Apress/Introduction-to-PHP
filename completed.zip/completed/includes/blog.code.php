<?php
#   blog.code.php

	$CONFIG=parse_ini_file('config.ini.php',true);
	require_once 'includes/db.php';
	require_once 'includes/default-library.php';
	require_once 'includes/library.php';

	$root = str_replace($_SERVER['SCRIPT_NAME'], '',
		$_SERVER['SCRIPT_FILENAME']);
	$host = $_SERVER['HTTP_HOST'];
	$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on'
		? 'https'
		: 'http';

	$title = $precis = $created = $updated = $article = $figure = $markdown = '';

	$id = intval($_GET['article'] ?? $_COOKIE['article']);

	$sql = "SELECT title, precis, created, updated, article, imageid, markdown
		FROM blog WHERE id=$id";
	$row = $pdo -> query($sql) -> fetch();

	if(!$row) {
		header("Location: $protocol://$host/bloglist.php");
		exit;
	}

	setcookie('article', $id, strtotime('+ 1 hour'));

	[$pagetitle, $precis, $created, $updated, $article, $imageid, $markdown]
		= $row;
	$pageheading = $pagetitle;

	$updated = $updated != $created
		? sprintf(' Updated: %s',
			date('d M Y g:i a', strtotime($updated)))
		: '';
	$created = date('d M Y g:i a', strtotime($created));

	if(!$markdown)	$article = pilcrow2p($article, true);
	else {
		$article = pilcrow2nl($article);
		$article = md2html($article);
		$markdown = ' class="markdown"';
	}

	//  Optional Image
		if($imageid) {
			$figure = '<figure>
				<a href="/images/scaled/%s">
					<img src="/images/thumbnails/%s" width="%s" height="%s"
						alt="%s">
				</a>
				<figcaption>%s</figcaption>
			</figure>';

			$sql = "SELECT title, src FROM images WHERE id=$imageid";
			[$title, $src] = $pdo -> query($sql) -> fetch();
			[$width, $height]
				= splitSize($CONFIG['images']['thumbnail-size']);

			$figure = sprintf(
				$figure,
				$src, $src, $width, $height, $title, $title
			);
		}

<?php
	//	dsn
		$dsn = 'mysql: host=localhost; dbname=australia; charset=utf8mb4';

		$user = 'ozadmin';
		$password = 'Test@321';

		$options = [
			PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
			PDO::ATTR_EMULATE_PREPARES => false,
		];

		try {
			$pdo = new PDO($dsn, $user, $password, $options);
		}
		catch (PDOException $e) {
			throw new PDOException($e->getMessage(), $e->getCode());
		}

	return $pdo;

<?php
#   admin-bloglist.code.php

    if(!session_id()) {
        session_start();
        session_regenerate_id(true);
    }

    $root = str_replace($_SERVER['SCRIPT_NAME'], '',
        $_SERVER['SCRIPT_FILENAME']);
    $host = $_SERVER['HTTP_HOST'];
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on'
        ? 'https'
        : 'http';

    if(!isset($_SESSION['user']) || !$_SESSION['admin']) {
        header("Location: $protocol://$host/admin.php");
        exit;
    }


    $pdo = require_once "$root/includes/db.php";
    require_once "$root/includes/library.php";
    require_once "$root/includes/default-library.php";

    $CONFIG = parse_ini_file("$root/config.ini.php",true);

	$tbody = $paging = $displaying = '';

	$page = intval($_GET['page'] ?? $_COOKIE['admin-bloglist-page']
        ?? 1) ?: 1;

    $limit = $CONFIG['admin-bloglist']['page-size'];
    $offset = ($page - 1) * $limit;

    $blogCount = $pdo -> query('SELECT count(*) FROM blog')
        -> fetchColumn();
    $pages = ceil($blogCount / $limit);

    $page = max(1, $page);          //  $page is at least 1
    $page = min($page, $pages);     //  $page is up to $pages
    setcookie('admin-bloglist-page', $page, strtotime('+ 1 hour'));

	$tr = '<tr><th>%s</th><td>%s</td><td>%s</td><td>%s</td>
        <td>%s</td><td>%s</td></tr>';

    $editButton = '<button name="prepare-update"
        value="%s">Edit</button>';
    $deleteButton = '<button name="prepare-delete"
        value="%s">Delete</button>';

	$sql="SELECT id, title, created, updated FROM blog
         ORDER BY id LIMIT $limit OFFSET $offset";

     $tbody = [];
     foreach($pdo->query($sql) as [$id, $title, $created, $updated]) {
		 $created = date('d M Y g:i a', strtotime($created));
         $updated = date('d M Y g:i a', strtotime($updated));
         $edit = sprintf($editButton, $id);
         $delete = sprintf($deleteButton, $id);
         $tbody[] = sprintf($tr, $id, $title, $created, $updated,
             $edit, $delete);
     }
     $tbody = implode($tbody);

    $paging = paging($page, $pages);
    $displaying = "Page $page of $pages";

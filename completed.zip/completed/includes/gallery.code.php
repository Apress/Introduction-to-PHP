<?php
	$root = str_replace($_SERVER['SCRIPT_NAME'], '',
		$_SERVER['SCRIPT_FILENAME']);

	$pdo = require_once "$root/includes/db.php";
	require_once "$root/includes/default-library.php";
	require_once "$root/includes/library.php";

	$CONFIG = parse_ini_file("$root/config.ini.php",true);

	$images = $paging = $displaying = '';
	$title = $image = $description = '';

	$page = intval($_GET['page'] ?? $_COOKIE['gallery-page'] ?? 1)
		?: 1;

	$limit = $CONFIG['gallery']['page-size'];
	$offset = ($page - 1) * $limit;

	$imageCount = $pdo -> query('SELECT count(*) FROM images
			WHERE gallery=true') -> fetchColumn();
	$pages = ceil($imageCount / $limit);

	$page = max(1, $page);          //  $page is at least 1
	$page = min($page, $pages);     //  $page is up to $pages
	setcookie('gallery-page', $page, strtotime('+ 1 hour'));

	$displaying = "Page $page of $pages";

	$sql = "SELECT id, title, src
		FROM images
		WHERE gallery=true
		ORDER BY id DESC LIMIT $limit OFFSET $offset";
	$results = $pdo -> query($sql);
	$a = '<a href="?image=%s"><img src="/images/thumbnails/%s"
		alt="%s" title="%s" width="%s" height="%s"></a>';
	$images = [];
	$ids = [];
	[$width, $height]
		= splitSize($CONFIG['images']['thumbnail-size']);
	foreach($results as $row) {
		$images[] = sprintf($a, $row['id'], $row['src'],
			$row['title'], $row['title'], $width, $height);
		$ids[] = $row['id'];
	}
	$images = implode($images);

	$paging = paging($page, $pages);

	$imageid = intval($_GET['image'] ?? $_COOKIE['gallery-image'] ?? 0)
		?: 0;
	$sql = "SELECT id FROM images WHERE gallery=true AND id=$imageid";
	$imageid = $pdo -> query($sql) -> fetchColumn();

	if(!$imageid) {
//  	$imageid = array_shift($ids);       //  First id
//  	$imageid = array_pop($ids);         //  Last id
//  	$imageid = $ids[array_rand($ids)];  //  Random id
		$imageid = $pdo -> query('SELECT id FROM images
			WHERE gallery=true ORDER BY rand()') -> fetchColumn();
	}

	//  setcookie('gallery-image', $imageid, strftime('+ 1 hour'));

	$sql = "SELECT title, src, description FROM images
		WHERE id=$imageid";
	[$title, $src, $description] = $pdo -> query($sql) -> fetch();

	$description = pilcrow2p($description);
	[$width, $height]
		= splitSize($CONFIG['images']['display-size']);
	$image = '<img src="/images/display/%s" alt="%s" title="%s"
		width="%s" height="%s">';
		$image = sprintf($image, $src, $title, $title, $width, $height);

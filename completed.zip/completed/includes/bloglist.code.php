<?php
#   bloglist.code.php

	$root = str_replace($_SERVER['SCRIPT_NAME'], '',
		$_SERVER['SCRIPT_FILENAME']);
	$host = $_SERVER['HTTP_HOST'];
	$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on'
		? 'https'
		: 'http';

	$pdo = require_once "$root/includes/db.php";
	require_once "$root/includes/library.php";
	require_once "$root/includes/default-library.php";

	$CONFIG = parse_ini_file("$root/config.ini.php",true);

    $articles = $paging = $displaying = '';

	$page = intval($_GET['page'] ?? $_COOKIE['bloglist-page'] ?? 1)
        ?: 1;

    $limit = $CONFIG['bloglist']['page-size'];
    $offset = ($page - 1) * $limit;

    $blogCount = $pdo -> query('SELECT count(*) FROM blog')
        -> fetchColumn();
    $pages = ceil($blogCount / $limit);

    $page = max(1, $page);
    $page = min($page, $pages);
    setcookie('bloglist-page', $page, strtotime('+ 1 hour'));

	$h2 = '<h2><a href="blogarticle.php?article=%s">%s</a></h2>';
    $div = '<div>%s<p class="date">%s%s</p>
        <p class="precis">%s</p></div>';

	$sql="SELECT id, title, created, updated, precis FROM blog
        ORDER BY id LIMIT $limit OFFSET $offset";

    $articles=[];
    $articles[] = '<div>';

    foreach($pdo -> query($sql) as [$id, $title, $created, $updated,
      $precis]) {
		$updated = $updated != $created
	        ? sprintf(' (Updated: %s)', date('d M Y g:i a',
	            strtotime($updated)))
	        : '';
	    $created = date('d M Y g:i a',strtotime($created));
	    $heading=sprintf($h2, $id, $title);
	    $articles[]=sprintf($div, $heading, $created,$updated, $precis);
    }

    $articles[] = '</div>';
    $articles=implode($articles);

	$paging = paging($page, $pages);
    $displaying = "Page $page of $pages";

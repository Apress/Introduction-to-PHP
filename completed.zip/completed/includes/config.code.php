<?php
	if(!session_id()) {
		session_start();
		session_regenerate_id(true);
	}

	$root = str_replace($_SERVER['SCRIPT_NAME'], '',
		$_SERVER['SCRIPT_FILENAME']);
	$host = $_SERVER['HTTP_HOST'];
	$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on'
		? 'https'
		: 'http';

	if(!isset($_SESSION['user']) || !$_SESSION['admin']) {
		header("Location: $protocol://$host/admin.php");
		exit;
	}

	require_once "$root/includes/db.php";
	require_once "$root/includes/default-library.php";

	$CONFIG = parse_ini_file("$root/config.ini.php",true);

	if(isset($_POST['save'])) {
		$settings = array_intersect_key($_POST, $CONFIG);
		$settings = array_replace_recursive($CONFIG, $settings);

		$ini = [];

		foreach($settings AS $name => $value) {
			if(!is_array($value)) $ini[] = "$name = $value";
			else {
				$ini[] = "[$name]";
				foreach($value as $name => $value) $ini[] = "\t$name = $value";
			}
		}

		$ini = implode("\r\n", $ini);

		file_put_contents("$root/config.ini.php",$ini);

		if(isset($_POST['resize'])) {
			foreach($pdo -> query('SELECT src FROM images') as [$src]) {
				if($settings['images']['display-size'] != $CONFIG['images']['display-size'])
				resizeImage(
					"{$root}/{$CONFIG['images']['directory']}/originals/{$src}",
					"{$root}/{$CONFIG['images']['directory']}/display/{$src}",
					$CONFIG['images']['display-size']
				);
				if($settings['images']['thumbnail-size'] != $CONFIG['images']['thumbnail-size'])
				resizeImage(
					"{$root}/{$CONFIG['images']['directory']}/originals/{$src}",
					"{$root}/{$CONFIG['images']['directory']}/thumbnails/{$src}",
					$CONFIG['images']['thumbnail-size']
				);
#				if($settings['images']['icon-size'] != $CONFIG['images']['icon-size'])
				resizeImage(
					"{$root}/{$CONFIG['images']['directory']}/originals/{$src}",
					"{$root}/{$CONFIG['images']['directory']}/icons/{$src}",
					$CONFIG['images']['icon-size']
				);
				if($settings['images']['scaled'] != $CONFIG['images']['scaled'])
				resizeImage(
					"{$root}/{$CONFIG['images']['directory']}/originals/{$src}",
					"{$root}/{$CONFIG['images']['directory']}/scaled/{$src}",
					$CONFIG['images']['scaled'], ['method'=>'scale']
				);
			}
		}

		$CONFIG = $settings;
	}

	$global = array_filter($CONFIG,'is_string');
	$sections = array_filter($CONFIG,'is_array');

	$thead = '<thead><tr><th colspan="2">%s</th></tr></thead>';
	$tr = '<tr><td>%s</td><td><input name="%s" value="%s"></tr>';

	$table = [];

	$table[] = sprintf($thead, '');
	$table[] = '<tbody>';
	foreach($global as $name => $value) {
		$table[] = sprintf($tr, $name, $name, $value);
	}
	$table[] = '</tbody>';

	foreach($sections as $section => $items) {
		$table[] = sprintf($thead, $section);
		$table[] = '<tbody>';
		foreach($items as $name => $value) {
			$table[] = sprintf($tr, $name, "{$section}[$name]", $value);
		}
		$table[] = '</tbody>';
	}

	$table = implode($table);

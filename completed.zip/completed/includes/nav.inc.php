<?php
	$current=basename($_SERVER['SCRIPT_FILENAME']);
	$links = [
		'Home' => 'index.php',
		'About Oz' => 'about.php',
		'Contact Us' => 'contact.php',
		'Oz Blog' => 'bloglist.php',
		'Animals' => 'gallery.php',
	];

	if(isset($_SESSION['user']) && $_SESSION['admin'])
		$text = "{$_SESSION['givenname']} {$_SESSION['familyname']}";
	else $text = 'Administration';

	$links[$text] = 'admin.php';

	$a = '<li><a href="/%s">%s</a></li>';
	$span = '<li><span>%s</span></li>';

	$ul = [];

	foreach($links as $text => $href) {
		$ul[] = $href == $current
			? sprintf($span, $text)
			: sprintf($a, $href, $text);
	}

	$ul = implode($ul);
?>
<nav>
	<ul>
		<?= $ul ?>
	</ul>
</nav>

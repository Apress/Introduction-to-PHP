		<footer>
			<span>Copyright © Down Under<br><?= "$date ($timezone)" ?></span><span><?= "PHP $version" ?></span>
		</footer>

<?php
	if(!session_id()) {
		session_start();
		session_regenerate_id(true);
	}

	$root = str_replace($_SERVER['SCRIPT_NAME'], '',
		$_SERVER['SCRIPT_FILENAME']);
	$host = $_SERVER['HTTP_HOST'];
	$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on'
		? 'https'
		: 'http';

	if(!isset($_SESSION['user']) || !$_SESSION['admin']) {
		header("Location: $protocol://$host/admin.php");
		exit;
	}


	$pdo = require_once "$root/includes/db.php";
	require_once "$root/includes/library.php";
	require_once "$root/includes/default-library.php";

	$CONFIG = parse_ini_file("$root/config.ini.php",true);

	$tbody = $paging = '';

	$page = intval($_GET['page'] ?? $_COOKIE['imagelist-page'] ?? 1)
			?: 1;

	$limit = $CONFIG['imagelist']['page-size'];
	$offset = ($page - 1) * $limit;

	$imageCount = $pdo -> query('SELECT count(*) FROM images') -> fetchColumn();
	$pages = ceil($imageCount / $limit);

	$page = max(1, $page);          //  $page is at least 1
	$page = min($page, $pages);     //  $page is up to $pages
	setcookie('imagelist-page', $page, strtotime('+ 1 hour'));

	$paging = paging($page, $pages);

	$sql = "SELECT id, title, src
		FROM images
		ORDER BY id LIMIT $limit OFFSET $offset";
	$results = $pdo -> query($sql);

	[$width, $height]
		= splitSize($CONFIG['images']['icon-size']);

	$tbody = [];
	$tr = '<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>';
	$img = '<a href="/images/display/%s"><img src="/images/icons/%s" alt="%s"
		title="%s" width="%s" height="%s"></a>';
	[$width, $height]
		= splitSize($CONFIG['images']['icon-size']);
	$editButton = '<button name="prepare-update" value="%s">Edit</button>';
	$removeButton = '<button name="prepare-delete" value="%s">Remove</button>';

	foreach($results as $row) {
		$tbody[] = sprintf(
			$tr,
			$row['id'],			//	id
			sprintf(				//	img element
				$img,
				$row['src'], $row['src'],
				$row['title'], $row['title'],
				$width, $height
			),
			$row['title'],		//	title
			sprintf($editButton, $row['id']),	//	edit button
			sprintf($removeButton, $row['id'])	//	remove button
		);

	}

	$tbody = implode($tbody);

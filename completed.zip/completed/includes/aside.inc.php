<aside id="photo">
	<?= $image ?>
	<h2><?= $title ?></h2>
	<div>
		<?= $description ?>
	</div>
</aside>

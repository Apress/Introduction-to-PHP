title = Australia Down Under
contact = Support <info@australia.example.com>
[images]
	directory = images
	display-size = 480 x 360
	thumbnail-size = 240 x 180
	icon-size = 40 x 30
	scaled = 50
[gallery]
	page-size = 3
[bloglist]
	page-size = 3
[imagelist]
	page-size = 6
[admin-bloglist]
	page-size = 4
[blogedit]
	use-image = buttons

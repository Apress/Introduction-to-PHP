/*	Ajax
	================================================ */

	'use strict';

	window.onerror=function(message,url,line) {
		alert(`Error: ${message}\n${url}: ${line}`);
	};

	init();
	function init() {
		ajaxContent();
		ajaxSlideshow();
		ajaxLightbox();
		ajaxCountries();
	}

	function ajaxContent() {

	}

	function ajaxSlideshow() {

	}

	function ajaxLightbox() {

	}

	function ajaxCountries() {

	}

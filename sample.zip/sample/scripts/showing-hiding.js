/**	Menu
	================================================
	================================================ */

	'use strict';

	window.onerror=function(message, url, line) {
		alert(`Error: ${message}\n${url}: ${line}`);
	};

	init();

	function init() {
		doHeadings();
		doMenu();
		doForm();
	}

	function doHeadings() {

	}

	function doMenu() {

	}

	function doForm() {

	}

/**	JavaScript Snippets
	================================================

	================================================ */


/**	02 - Guessing Game
	================================================

	================================================ */

/*	02.01 - Initial Code
	================================================
	HTML:

	<script type="text/javascript" src="scripts/game.js"
		crossorigin="anonymous" defer></script>
	================================================ */

	'use strict';

	window.onerror=function(message,url,line) {
		alert(`Error: ${message}\n${url}: ${line}`);
	};

	init();
	function init() {

	}

/*	02.02 - random() Function
	================================================ */

	function random(max) {
		//  returns a random number from 1 … max
		return Math.floor(Math.random()*max)+1;
	}

/*	02.03 - Link to Library
	================================================
	HTML

	<script type="text/javascript" src="scripts/library.js"
		crossorigin="anonymous"></script>
	================================================ */

/*	02.04 - Finished Code
	================================================ */

	function playGame() {
		//  Set up the data
			let min, max;
			let answer, guess;
			let message;

		//  Initialise
			[min,max] = [1,100];
			answer = random(100);
			message = 'Guess the Number';

		do {
			guess = prompt(`${message}\nFrom ${min} to ${max}`);
			if(guess === null) return 'game cancelled';
			guess = parseInt(guess) || 0;

			if(guess < answer) {    //  Too Small
				message = 'Too Low';
				min = guess + 1;
			}
			else if(guess > answer) {   //  Too Big
				message = 'Too High';
				max = guess - 1;
			}
			else {                      //  Correct
				alert('Correct');
			}
		} while(guess != answer);

		return 'game over';
	}


/**	04 - Slide Show
	================================================

	================================================ */

/*  04.01 - Initial Code
	================================================
	HTML:

	<script type="text/javascript" src="scripts/game.js"
		crossorigin="anonymous" defer></script>
	================================================ */

	'use strict';
	window.onerror=function(message,url,line) {
		alert(`Error: ${message}\n${url}: ${line}`);
	};

	init();

	function init() {

	}

/*	04.02 - slideShow() Stub
	================================================
	================================================ */

	/*  doSlides(images, containerSelector)
		================================================
		Turns a container element into an slide show
		with a collection of images.
		================================================ */

		function doSlides(images, containerSelector) {

		}

/*	04.03 - Array of Image Names
	================================================
	Use let images = […]
	================================================ */

	var images = [
		'bamboo.jpg', 'bird.jpg', 'bromeliad.jpg',
		'bush-panorama.jpg', 'canal.jpg', 'church.jpg',
		'cityscape.jpg', 'emu.jpg', 'gum-nuts.jpg',
		'hanging-rock.jpg', 'hut.jpg', 'koala.jpg',
		'kookaburra.jpg', 'lake.jpg', 'lantern.jpg',
		'light-house.jpg', 'lorikeet.jpg', 'mountain-panorama.jpg',
		'rocks.jpg', 'rose.jpg', 'steps.jpg',
		'sunset.jpg', 'tall-trees.jpg', 'tea-leaf.jpg',
		'train.jpg','waterfall.jpg'
	];

/*	04.03 - Array of Image Names
	================================================
	Use let images = […]
	================================================ */

	var images = [
		{ src: 'bamboo.jpg', caption: 'Bamboo Forest In Japan' },
		{ src: 'bird.jpg', caption: 'Bird in Flight' },
		{ src: 'bromeliad.jpg', caption: 'Bromeliad Flower' },
		{ src: 'bush-panorama.jpg', caption: 'Panorama of Australian Bush' },
		{ src: 'canal.jpg', caption: 'A Canal in Holland' },
		{ src: 'church.jpg', caption: 'Old Church in Brisbane at Night' },
		{ src: 'cityscape.jpg', caption: 'A City in Japan' },
		{ src: 'emu.jpg', caption: 'Australian Emu' },
		{ src: 'gum-nuts.jpg', caption: 'Some Gum Nuts' },
		{ src: 'hanging-rock.jpg', caption: 'Rock Out Crops in Victoria' },
		{ src: 'hut.jpg', caption: 'Old Bush Hut' },
		{ src: 'koala.jpg', caption: 'A Koala doing what Koalas normally do …' },
		{ src: 'kookaburra.jpg', caption: 'A Kookaburra Looking Back' },
		{ src: 'lake.jpg', caption: 'A Lake in Japan' },
		{ src: 'lantern.jpg', caption: 'Lantern at a Japanese Shrine' },
		{ src: 'light-house.jpg', caption: 'A Light House' },
		{ src: 'lorikeet.jpg', caption: 'Australian Lorikeet' },
		{ src: 'mountain-panorama.jpg', caption: 'Mountain Panorama in Japan' },
		{ src: 'rocks.jpg', caption: 'Rock Outcrop in Lake' },
		{ src: 'rose.jpg', caption: 'A Yellow Rose' },
		{ src: 'steps.jpg', caption: 'Stone Steps in a Garden' },
		{ src: 'sunset.jpg', caption: 'Sunset in the Clouds' },
		{ src: 'tall-trees.jpg', caption: 'Trees in Australian Bush' },
		{ src: 'tea-leaf.jpg', caption: 'A Leaf of the Camellia Sinensis Plant' },
		{ src: 'train.jpg', caption: 'Train approaching the Station' },
		{ src: 'waterfall.jpg', caption: 'Waterfall in the Wood' }
	];

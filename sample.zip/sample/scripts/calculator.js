/*	Mortgage Calculator
	================================================ */

	'use strict';

	window.onerror=function(message,url,line) {
		alert(`Error: ${message}\n${url}: ${line}`);
	};

	doCalculator();

	function doCalculator() {

	}

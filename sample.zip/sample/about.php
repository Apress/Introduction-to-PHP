<?php #require_once 'includes/aside.code.php'; ?>
<?php
	//	Page Title and Heading
		$pagetitle = 'About';
		$pageheading = 'About this Site';

	require_once 'includes/head.inc.php';
?>
<body>
<?php require_once 'includes/header.inc.php'; ?>
<?php require_once 'includes/nav.inc.php'; ?>
	<main>
		<article id="about">
			<p>This site is the sample site for the book <b>Introduction to PHP</b>.</p>
			<p>Images were gathered from Wikipedia, and are distributed
				under a license which permits this sort of thing.</p>
			<p>If you want to look around, you are welcome to do so.</p>
		</article>
		<?php require_once 'includes/aside.inc.php'; ?>
	</main>
<?php require_once 'includes/footer.inc.php'; ?>
</body>
</html>
